//
//  ViewController.swift
//  MyGallery
//
//  Created by bhavsarzeel on 17/07/23.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController  {

    @IBOutlet weak var btnLogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
//        GIDSignIn.sharedInstance.delegate = self
    }
    #warning("Cannot find type 'GoogleSignInDelegate' in scope thats why i can't implement code of google sign in authentication")
    @IBAction func btnLogin(_ sender: UIButton) {
//        signInGoogle()
    }
    func signInGoogle() {
//            GIDSignIn.sharedInstance.signIn()
        }
    // MARK: - GIDSignInDelegate
        func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }
//            let name = user.profile?.name
//            let email = user.profile?.email
//            let profileUrl = user.profile?.imageURL(withDimension: .min)
            print("Signed in successfully")
//            performSegue(withIdentifier: "ImageVCSegue", sender: self)
        }
#warning("PassLogin Detail To Another Page")
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "ImageVCSegue" {
                // Get a reference to the destination view controller
                guard let secondViewController = segue.destination as? ImageVC else {
                    return
                }
//                secondViewController.name = name
//                secondViewController.email = email
//                secondViewController.profileUrl = profileUrl
            }
        }
    @IBAction func unwindToFirst(_ unwindSegue: UIStoryboardSegue) {
    }
}

