//
//  ImageVC.swift
//  MyGallery
//
//  Created by bhavsarzeel on 17/07/23.
//

import UIKit

//var name = ""
//var email = ""
//var profileUrl = ""

class ImageVC: UIViewController {
    
    var imageUrl = "https://picsum.photos/v2/list"
    var myImageArray = [ImageClass]()
    var myIndex = 0
    
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchImages()
    }
    
    func fetchImages() {
        guard let url = URL(string: imageUrl) else {
            print("Invalid URL")
            return
        }
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: url) { [weak self] (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                let jsonArray = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]]
                
                guard let imageArray = jsonArray else {
                    print("Invalid JSON data")
                    return
                }
                
                for imageDict in imageArray {
                    let imageObject = ImageClass(dict: imageDict)
                    self?.myImageArray.append(imageObject)
                }
                
                DispatchQueue.main.async {
                    self?.myCollectionView.reloadData()
                }
            } catch {
                print("Error parsing JSON: \(error)")
            }
        }
        
        task.resume()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? SecondImageVC {
            destinationVC.myIndex = myIndex
            destinationVC.myImageList = myImageArray
        }
    }
}

extension ImageVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myImageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! ImageVCCell
        
        let imageObject = myImageArray[indexPath.row]
        cell.myImageView.image = imageObject.localImage ?? UIImage(named: "placeholder")
        
        if imageObject.localImage == nil {
            imageObject.downloadImage { [weak cell] (image) in
                DispatchQueue.main.async {
                    if let image = image {
                        cell?.myImageView.image = image
                    }
                }
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "FinalImage", sender: self)
    }
}


extension ImageVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionViewWidth = collectionView.bounds.width
        let itemWidth = collectionViewWidth / 3.0
        let itemHeight = itemWidth // Assuming square items
        
        return CGSize(width: itemWidth, height: itemHeight)
    }
    
    // Implement other methods of UICollectionViewDelegateFlowLayout if needed
}



