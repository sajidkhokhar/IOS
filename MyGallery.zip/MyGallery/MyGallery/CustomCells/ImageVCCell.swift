//
//  ImageVCCell.swift
//  MyGallery
//
//  Created by bhavsarzeel on 17/07/23.
//

import UIKit

class ImageVCCell: UICollectionViewCell {
    
    @IBOutlet weak var myScrollView: UIScrollView!
    @IBOutlet weak var imgSecondVC: UIImageView!
    @IBOutlet weak var myImageView: UIImageView!
    override func awakeFromNib() {
            super.awakeFromNib()
        }
}
