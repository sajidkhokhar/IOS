//
//  ImageClass.swift
//  MyGallery
//
//  Created by bhavsarzeel on 17/07/23.
//

import UIKit

class ImageClass: NSObject {
    var myImage: String
    var localImage: UIImage?
    
    init(dict: [String: Any]) {
        if let downloadURL = dict["download_url"] as? String {
            myImage = downloadURL
        } else {
            myImage = ""
        }
    }
    
    func downloadImage(completion: @escaping (UIImage?) -> Void) {
        guard let imageURL = URL(string: myImage) else {
            completion(nil)
            return
        }
        
        if let cachedImage = localImage {
            completion(cachedImage)
            return
        }
        
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: imageURL), let image = UIImage(data: data) {
                self?.localImage = image
                completion(image)
            } else {
                completion(nil)
            }
        }
    }
}
